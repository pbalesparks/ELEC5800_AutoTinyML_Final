#pragma once

#ifndef MIDDLEWARES_QEEXO_INCLUDE_APPS_QXAUTOMLCONFIG_USER_H_
#define MIDDLEWARES_QEEXO_INCLUDE_APPS_QXAUTOMLCONFIG_USER_H_

#ifdef __cplusplus
extern "C" {
#endif

/************************************************
 * SENSOR ENABLE DEFINITIONS
 ************************************************/
 #define QXAUTOMLCONFIG_SENSOR_ENABLE_ACCEL
 #define QXAUTOMLCONFIG_SENSOR_ENABLE_GYRO

#ifdef QXAUTOMLCONFIG_SENSOR_ENABLE_ACCEL
#define QXAUTOMLCONFIG_SENSOR_ACCEL_FSR  16.0f
#define QXAUTOMLCONFIG_SENSOR_ACCEL_ODR  952.0f
#define QXAUTOMLCONFIG_SENSOR_ACCEL_BUFCOUNT  1332
#define QXAUTOMLCONFIG_SENSOR_ACCEL_BYTES_PER_SAMPLE  6
#endif

#ifdef QXAUTOMLCONFIG_SENSOR_ENABLE_GYRO
#define QXAUTOMLCONFIG_SENSOR_GYRO_FSR  2000.0f
#define QXAUTOMLCONFIG_SENSOR_GYRO_ODR  952.0f
#define QXAUTOMLCONFIG_SENSOR_GYRO_BUFCOUNT  1332
#define QXAUTOMLCONFIG_SENSOR_GYRO_BYTES_PER_SAMPLE  6
#endif

/* sensor type definitions inside inference Engine. 
 * Customer should define the sensor index as the same sequence regarding to 
 * fill the prediction data buffer with multiple sensors*/
typedef enum {
  SENSOR_TYPE_NONE = 0, /*!< None defined sensor */
  SENSOR_TYPE_ACCEL, /*!< Default accelerometer sensor */
  SENSOR_TYPE_GYRO, /*!< Default gyroscope sensor */
  SENSOR_TYPE_MAG, /*!< Megnotometer sensor */
  SENSOR_TYPE_PRESSURE, /*!< Pressure sensor */
  SENSOR_TYPE_TEMPERATURE, /*!< Temperature sensor */
  SENSOR_TYPE_HUMIDITY, /*!< Humidity sensor */
  SENSOR_TYPE_MICROPHONE, /*!< Microphone sensor */
  
  SENSOR_TYPE_ACCEL_LOWPOWER, /*!< Additional lowpower accelometer sensor */
  SENSOR_TYPE_ACCEL_HIGHSENSITIVE, /*!< Additional high sensitive accelometer sensor */
  SENSOR_TYPE_TEMPERATURE_EXT1, /*!< Additional temperature sensor */
  SENSOR_TYPE_PROXIMITY, /*!< Proximity sensor */
  SENSOR_TYPE_AMBIENT, /*!< Ambient light sensor */
  SENSOR_TYPE_LIGHT,  /*!<Light sensor with one axis>*/

  SENSOR_TYPE_TVOC, /*!< ZMOD gas sensor (TVOC) */
  SENSOR_TYPE_ECO2, /*!< ZMOD gas sensor (ECO2) */
  SENSOR_TYPE_ETOH, /*!< ZMOD gas sensor (ETOH) */
  SENSOR_TYPE_RCDA, /*!< ZMOD gas sensor (RCDA) */
  SENSOR_TYPE_IAQ, /*!< ZMOD gas sensor (IAQ) */
  SENSOR_TYPE_RMOX, /*!< ZMOD gas sensor (MOx array) */
  SENSOR_TYPE_MAX
}QXOSensorType;

/* Qeexo static engine APIs */
extern void QxFillSensorData(QXOSensorType type, void* data, int data_len);
extern int QxClassify(void);

/* Desired period of time between the start of the previous classification and the next request for classification (in msecs) */
#define PRED_CLASSIFICATION_INTERVAL_IN_MSECS 100

#ifdef __cplusplus
}
#endif

#endif /* MIDDLEWARES_QEEXO_INCLUDE_APPS_QXAUTOMLCONFIG_USER_H_ */
